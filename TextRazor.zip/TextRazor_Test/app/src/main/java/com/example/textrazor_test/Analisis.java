package com.example.textrazor_test;

import com.textrazor.annotations.Entity;
import com.textrazor.annotations.NounPhrase;
import com.textrazor.annotations.Word;

import java.util.ArrayList;

public class Analisis {
    ArrayList<Word> listaWords = new ArrayList<Word>();
    ArrayList<NounPhrase> listaPhrases = new ArrayList<NounPhrase>();
    ArrayList<Entity> listaEntities = new ArrayList<Entity>();

}
